public class EntityOfRequestDoesNotExits extends Exception{
    public EntityOfRequestDoesNotExits() {
        System.out.println("This entity does not exist in the organization.");
    }
}
