public class NegativeQuantity extends Exception{
    public NegativeQuantity() {
        System.out.println("You cannot insert negative quantity.");
    }
}
