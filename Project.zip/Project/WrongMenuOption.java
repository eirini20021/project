public class WrongMenuOption extends Exception {
    public WrongMenuOption() {
        System.out.println("You must enter one of the options.");
    }
}
